package basic;

public interface Files {
	public static final String PARCELMINOES_LOGO="C:\\Users\\husam\\test\\Pentominoes_Phase_3\\Resources\\BG.png";
	public static final String MAIN_BG="C:\\Users\\husam\\test\\Pentominoes_Phase_3\\Resources\\mainBG.png";
	public static final String BG="C:\\Users\\husam\\test\\Pentominoes_Phase_3\\Resources\\BG.png";
}
//percentage filled
//time taken
//total value
//Theoritical best values
//Number of parcels used A B C