# Pentominoes_Phase_3
# This is the Phase 3 project
# Group_6_DKE
We can fork this to the repository from DKE to hand it in instantly at the time of the deadline, so that's nice
